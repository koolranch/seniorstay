import React from 'react';
import type { Metadata, Viewport } from 'next';
import './globals.css';
import { ComparisonProvider } from '@/context/ComparisonContext';
import GoogleMapsScript from '@/components/map/GoogleMapsScript';

export const metadata: Metadata = {
  title: 'Ray Senior Placement | Find Assisted Living & Senior Care Options',
  description: 'Find the perfect senior living community with Ray Senior Placement. Compare assisted living, memory care, and independent living options.',
};

export const viewport: Viewport = {
  width: 'device-width',
  initialScale: 1,
  maximumScale: 5,
  userScalable: true,
  viewportFit: 'cover',
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className="min-h-screen bg-white antialiased">
        <ComparisonProvider>
          {children}
        </ComparisonProvider>
        <GoogleMapsScript />
      </body>
    </html>
  );
}
